// buscar.php
<?php
// Conecta con la base de datos y realiza la búsqueda
$term = $_POST['term'];
// Realiza la búsqueda en tu base de datos y devuelve los resultados en formato HTML
// Aquí asumimos que tienes una función que maneja la búsqueda en la base de datos.

$resultados = buscarTesisEnBaseDeDatos($term);

// Genera la salida HTML
foreach ($resultados as $resultado) {
    echo "<p>Título: " . $resultado['titulo'] . "<br>Autor: " . $resultado['autor'] . "</p>";
}
?>
