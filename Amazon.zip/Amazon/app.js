// app.js
function buscarTesis() {
    // Obtener el término de búsqueda del campo de entrada
    var term = document.getElementById("searchInput").value;

    // Realizar una solicitud AJAX para buscar tesis en la base de datos
    // y mostrar los resultados en el div "resultadoBusqueda"
    // Puedes utilizar JavaScript puro o bibliotecas como jQuery para esto.
    // Aquí se asume que se utiliza jQuery.

    $.ajax({
        url: 'backend/buscar.php', // Ruta de tu script de búsqueda en el servidor
        method: 'POST',
        data: { term: term },
        success: function (response) {
            document.getElementById("resultadoBusqueda").innerHTML = response;
        }
    });
}
